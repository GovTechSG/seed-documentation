#!/bin/bash

#Text color scheme: _ (Informative), Green(Successful Action), Red(Unsuccessful Action)

#requires sudo

######################################################
####### VERIFYING THAT USER ORGANIZATION IS CORRECT###
######################################################

#Constants
atp_wog_org_id="faa36a5e-2da6-4225-8e27-226177c801a0"
atp_tp_org_id="49237d71-42ac-425a-a803-881b92cc18ce"
atp_hive_org_id="6389e966-e334-461d-86ce-0fed12484620"
intune_profile_identifier="Microsoft.Profiles.MDM"

formsg_url="https://form.gov.sg/63c62c20d4e11c0012f59e90"
formsg_intune_prefill_id="63c62f51f2bd6c00127c7342"
formsg_able_to_offboard_prefill_id="6406f7dbbb9c3d00126e20dc"
formsg_url_with_prefill="$formsg_url?formsg_able_to_offboard_prefill_id=Yes&$formsg_intune_prefill_id"
tp_support_form="https://form.gov.sg/5f69797d0666cb0011cc59da"

ERROR='\033[0;31m'
INFO='\033[0;36m'
SUCCESS='\033[0;32m'
NC='\033[0m' # No Color

org_id_pattern='^[0-9a-fA-F]{8}-([0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}$'
intune_id_pattern='^[0-9a-fA-F]{8}-([0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}$'

intune_id="$(security find-certificate -a /Library/Keychains/System.keychain | egrep -B 4 '\"issu\"<blob>=.+MICROSOFT INTUNE MDM DEVICE CA' | grep alis | cut -d '"' -f 4)"

reset_device () {
    # Note: verify_defender_offboarding_script will also offboard & uninstall defender
    verify_defender_offboarding_script || exit
    uninstall_cloudflare
    reset_hardenings_settings
    uninstall_tanium
    unenroll_intune
    uninstall_apps
    serverside_offboarding_redirect
}

# Verify that user has an OrgID in registry, and that it is a valid OrgID (Either WOG or TP)
# Use "return" if we want to exit this function but continue script invocation. Use "exit" if we want to completely exit script invocation
verify_defender_offboarding_script() {
    user_org_id=$(mdatp health --field org_id | cut -d '"' -f 2)
    # If org_id does not exist, we skip offboarding
    if [ -z $user_org_id ]; then
        echo -e "${ERROR}User OrgID Property does not exist. Skipping offboarding from Defender... \n\n"
        return
    fi
    # If org_id is invalid, we error out
    if ! [[ $user_org_id =~ $org_id_pattern ]] ; then
        echo -e "${ERROR}User OrgID Property is invalid."
        echo -e "${ERROR}Please raise a service request to TechPass via this form: $tp_support_form"
        exit
    fi

    # Get the user organization name from org id
    user_org_name=$(get_user_org_name $user_org_id)
    if [[ $user_org_name == "" ]]; then
        echo -e "${ERROR}Unknown Tenant detected: Offboarding script is only meant for SEED users, which must be from either WOG or TP"
        echo -e "${ERROR}Please raise a service request to TechPass via this form: $tp_support_form"
        exit
    fi
    echo -e "${SUCCESS}User belongs to $user_org_name Organization"
    
    defender_offboarding_script_name=$(find . -name "*_valid_until_*.sh")
    defender_offboarding_script_org_id=""
    defender_offboarding_script_contents=`cat ${defender_offboarding_script_name}`

    # This pattern is different from the one above
    org_id_pattern_for_script='([0-9a-f]+-){4,}[0-9a-f]+'
    # Check if defender script Org Id is valid
    if [[ $defender_offboarding_script_contents =~ $org_id_pattern_for_script ]] ; then
        defender_offboarding_script_org_id=${BASH_REMATCH[0]}
        if [ "$user_org_id" != "$defender_offboarding_script_org_id" ]; then
            echo -e "${ERROR}Incorrect Defender Script used"
            echo -e "${INFO}Please download the offboarding package for the Organisation with ID $user_org_id at docs portal"
            exit
        fi
    else
        echo -e "${ERROR}Incorrect Defender Script used"
        echo -e "${INFO}Please download the offboarding package for the Organisation with ID $user_org_id at docs portal"
        echo -e "${INFO}If this issue persists, please raise a service request to TechPass via this form: $tp_support_form"
        exit
    fi

    # ToDo: extract expiry date from the offboarding script filename
    current_date=$(date +%F)
    defender_offboarding_script_expiry_date=""
    expiry_date_pattern='[0-9]{4}-[0-9]{2}-[0-9]{2}'
    if [[ $defender_offboarding_script_name =~ $expiry_date_pattern ]] ; then
        defender_offboarding_script_expiry_date=${BASH_REMATCH[0]}
    fi

    # ToDo: Verify that script hasn't expired yet
    if [[ $current_date > $defender_offboarding_script_expiry_date ]]; then
        echo -e "${ERROR}Defender Script has expired! Please download a new offboarding package from docs portal"
        echo -e "${INFO}If this issue persists, please raise a service request to TechPass via this form: $tp_support_form."
        exit
    fi

    # If all the previous checks has passed, run the offboard_from_defender function
    echo -e "${SUCCESS}Verification of Defender Offboarding Script Successful! Proceeding with offboarding from Defender \n\n"
    offboard_from_defender $defender_offboarding_script_name
    uninstall_defender
}


get_user_org_name () {
    case "$1" in 
        $atp_wog_org_id)
            echo -e "WOG"
            ;;
        
        $atp_tp_org_id)
            echo -e "TP"
            ;;

        $atp_hive_org_id)
            echo -e "HIVE"
            ;;
    *)
        echo -e ""
    ;;
    esac
}


# Once all the verification has been done we can begin offboarding
##############################################################################
##################### OFFBOARDING FROM DEFENDER ######################
##############################################################################
offboard_from_defender() {
    echo -e "${INFO}Offboarding device from defender..."
    /bin/sh $1 > defender_offboarding_output.txt 2>&1
    if [ "$?" -ne 0 ]; then
        echo -e "${ERROR}Unsuccessful offboarding from Microsoft Defender for Endpoint"
        echo -e "${INFO}Please restart your computer and re-run this offboarding script."
        echo -e "${INFO}If this issue persists, please raise a service request to TechPass via this form: $tp_support_form. Provide the file 'defender_offboarding_output.txt' under the 'attachments' section"
        exit
    else
        echo -e "${SUCCESS}Device offboarded from Microsoft Defender for Endpoint \n\n"
    fi
}


##############################################################################
####################### UNINSTALLING MICROSOFT DEFENDER ########################
##############################################################################
uninstall_defender() {
    if !(open -Ra "Microsoft Defender.app") ; then
        echo -e "${SUCCESS}Microsoft Defender not installed. Skipping uninstallation... \n\n"
        return
    fi
    echo -e "${INFO}Uninstalling Microsoft Defender... \n\n"
    if ('/Library/Application Support/Microsoft/Defender/uninstall/uninstall') > /dev/null 2>&1 ; then
        echo -e "${SUCCESS}Microsoft Defender successfully uninstalled \n\n"
    else
        echo -e "${ERROR}Microsoft Defender could not be uninstalled. Please restart your computer and re-run this offboarding script \n\n"
        exit
    fi
}
##############################################################################
########################## UNINSTALLING WARP CLIENT ##########################
##############################################################################
uninstall_cloudflare () {
    # If WARP does not exist
    if !(open -Ra "Cloudflare WARP.app") > /dev/null 2>&1 ; then
        echo -e "${SUCCESS}Cloudflare WARP application not found. Skipping uninstallation... \n\n"
        return
    fi
    echo -e "${INFO}Cloudflare WARP application found. Proceeding with uninstallation"
    if (yes | /bin/sh /Applications/Cloudflare\ WARP.app/Contents/Resources/uninstall.sh); then
        echo -e "${SUCCESS}Cloudflare WARP successfully uninstalled \n\n"
    else
        echo -e "${ERROR}Cloudflare WARP could not be uninstalled \n\n"
    fi
}

##############################################################################
######################### ROLLBACK EMPIRICAL SETTINGS ########################
##############################################################################
reset_hardenings_settings () {
    echo -e "${INFO}Resetting security settings..."
    reset_login_banner
    reset_cli_login_banner
    reset_password_policies
    echo -e "${SUCCESS}Security settings successfully reset \n\n"
}

reset_login_banner () {
    local friendly_name="GUI login banner"
    local banner_file="/Library/Security/PolicyBanner.txt"

    if [ -e "$banner_file" ]; then
        echo -e "${INFO}Resetting $friendly_name"
        rm $banner_file
    else
        echo -e "${INFO}$friendly_name has already been reset" 
    fi
}

reset_cli_login_banner () {
    local friendly_name="command line login banner"
    local banner_file="/etc/motd"

    if [ -e "$banner_file" ]; then
        echo -e "${INFO}resetting $friendly_name"
        rm $banner_file
    else
        echo -e "${INFO}$friendly_name has already been reset" 
    fi
}

reset_password_policies() {
    echo -e "${INFO}removing all password policies"

    pwpolicy - clearaccountpolicies

    while IFS= read -r user_name; do
        if [ "$user_name" != "" ]; then
            pwpolicy -u "$user_name" -clearaccountpolicies
        fi
    done <<< "$user_list"
    
}
##############################################################################
######################### UNINSTALLING TANIUM CLIENT #########################
##############################################################################
uninstall_tanium() {
    # If the /TaniumClient folder does not exist, means Tanium 
    if [ ! -d "/Library/Tanium/TaniumClient" ] ; then
        echo -e "${SUCCESS}Tanium Client not found. Skipping uninstallation \n\n"
        return
    else
        echo -e "${INFO}Taniun Client found"
        echo -e "${INFO}Running Tanium Client uninstallation."
    fi
    
    launchctl unload /Library/LaunchDaemons/com.tanium.taniumclient.plist
    launchctl remove com.tanium.taniumclient > /dev/null 2>&1
    rm /Library/LaunchDaemons/com.tanium.taniumclient.plist
    rm /Library/LaunchDaemons/com.tanium.trace.recorder.plist
    rm -rf /Library/Tanium/
    rm /var/db/receipts/com.tanium.taniumclient.TaniumClient.pkg.bom
    rm /var/db/receipts/com.tanium.taniumclient.TaniumClient.pkg.plist
    rm /var/db/receipts/com.tanium.tanium.client.bom
    rm /var/db/receipts/com.tanium.tanium.client.plist
    pkgutil --forget com.tanium.client
    echo -e "${SUCCESS}Tanium Client uninstalled \n\n"
}


unenroll_intune () {
    # Check if intune profile exists (exit code 0 = exists, 1 = don't exist)
    sudo profiles -P | egrep -q ": ${intune_profile_identifier}$"
    if [ "$?" == 0 ]; then
        echo -e "${SUCCESS}Intune profile found. Proceeding with Intune unenrollment..."
    else
        echo -e "${ERROR}Intune profile not found. User has already unenrolled from intune. Skipping automated intune unenrollment..."
        echo -e "${INFO}Please manually check that your device has successfully unenrolled from Intune \n\n"
        return
    fi

    echo -e "${INFO}Unenrolling device from Intune..."
    sudo profiles -R -p $intune_profile_identifier

    sudo profiles -P | egrep -q ": ${intune_profile_identifier}$"
    # If the intune profile is no longer found, it means the device has successfully unenrolled from Intune
    if [ "$?" -ne 0 ]; then
        echo -e "${SUCCESS}Device successfully unenrolled from Intune \n\n"
    else
        echo -e "${ERROR}Automated intune unenrollment unsuccesful. Please proceed with manual intune unenrollment \n\n"
    fi
}


uninstall_apps () {
    echo -e "${INFO}Checking local offboarding status..."
    offboarding_successfully_completed=1  

    # check whether all software has been successfully uninstalled
    if (open -Ra "Cloudflare WARP.app") > /dev/null 2>&1 ; then
        echo -e "${ERROR}Cloudflare WARP failed to uninstall"
        offboarding_successfully_completed=0
    else
        echo -e "${SUCCESS}Cloudflare WARP successfully uninstalled"    
    fi

    # Todo: Check that Defender has been successfully uninstalled
    if (open -Ra "Microsoft Defender.app") > /dev/null 2>&1 ; then
        echo -e "${ERROR}Microsoft Defender failed to uninstall"
        offboarding_successfully_completed=0
    else
        echo -e "${SUCCESS}Microsoft Defender successfully uninstalled"
    fi

    # Check that Tanium has been successfully uninstalled
    if [ -d "/Library/Tanium/TaniumClient" ]; then
        echo -e "${ERROR}Tanium Client failed to uninstall"
        offboarding_successfully_completed=0
    else
        echo -e "${SUCCESS}Tanium Client successfully uninstalled"
    fi

    # Check that Intune unenrollment was successful
    sudo profiles -P | egrep -q ": ${intune_profile_identifier}$"
    if [ "$?" -ne 0 ]; then
        echo -e "${SUCCESS}User has unenrolled from Intune. Please manually confirm that unenrollment was successful."
    else
        echo -e "${ERROR}Automated intune unenrollment was unsuccesful. Manual intune unenrollment is required."
        # We consider script invocation as successful even though intune unenrollment is unsuccessful
        # offboarding_successfully_completed=0
    fi

    if [ "$offboarding_successfully_completed" -eq 1 ]; then
        echo -e "${SUCCESS}Local Offboarding successfully completed! \n\n"        
        echo -e "${INFO}If you require TechPass support, you can contact them via this form: $tp_support_form"
    else
        echo -e "\n"
        echo -e "${INFO}Please contact TechPass support via this form if any local offboarding issues persist: $tp_support_form"
    fi

    echo -e "\n"
}


serverside_offboarding_redirect() {
    if ! [[ $intune_id =~ $intune_id_pattern ]]; then
        echo -e "${ERROR}Intune ID not found/invalid. Resorting to manual input for Intune ID. \n"
        echo -e "${INFO}You may retrieve your Intune ID via the following 2 options:"
        echo -e "${INFO}Option 1. If you have access to TechPass portal (https://portal.techpass.gov.sg/secure/account/profile) on your Non-SE GSIB, go to TechPass portal > My Account > Profile. Retrieve your device's IntuneID from the table. \n"
        echo -e "${INFO}Option 2. If you do not have access to TechPass portal, raise a service request to retrieve your Intune ID via this form: $tp_support_form \n\n"
        echo -e "${INFO}Redirecting user to server-side offboarding Form in 10 seconds. Do ensure you have read the above instructions..."
        sleep 10
        open "$formsg_url?$formsg_able_to_offboard_prefill_id=Yes"
    else
        echo -e "${INFO}In a few seconds, you will be redirected to a form that will offboard your device from our servers."
        echo -e "${INFO}Submitting this form triggers certain backend clean up actions which are REQUIRED to complete your offboarding."
        echo -e "${INFO}You should receive an email notifying you of successful offboarding a few minutes after the form is submitted."
        sleep 5
        echo -e "${INFO}Redirecting to form in 3 seconds..."
        sleep 3
        open "$formsg_url_with_prefill=${intune_id}"
    fi
}

reset_device